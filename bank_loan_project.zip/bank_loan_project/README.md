# 🏦 Bank Loan Risk Analysis & Default Prediction

**Author:** K V S R S Gopi Chand  
**Tools:** Python | SQL | Excel | Power BI  
**Dataset:** 5,000 Indian Bank Loan Records (2020–2024)  
**Model AUC Score:** 0.992

---

## 📌 Project Overview

This end-to-end financial data analysis project focuses on identifying **loan default risk patterns** across 5,000 bank loan records. It covers data validation, exploratory analysis, SQL querying, financial reconciliation, and machine learning-based default prediction — skills directly applicable to roles in **financial data operations, risk analytics, audit support, and compliance.**

---

## 🎯 Business Problem

A bank needs to:
1. Understand **which loan segments carry the highest default risk**
2. Identify **patterns in borrower behavior** that lead to defaults
3. Build a **predictive model** to flag high-risk loans before disbursement
4. Generate **management reports** for stakeholders and audit teams

---

## 📁 Project Structure

```
bank_loan_project/
│
├── data/
│   └── bank_loan_data.csv          # 5,000 loan records (18 features)
│
├── sql/
│   └── loan_analysis_queries.sql   # 10 business SQL queries
│
├── outputs/
│   ├── 01_executive_dashboard.png  # KPI cards + key charts
│   ├── 02_risk_analysis.png        # Deep-dive risk analysis
│   ├── 03_ml_model.png             # ML model results
│   └── Loan_Analysis_Report.xlsx   # Multi-sheet Excel report
│
├── loan_analysis.py                # Main Python analysis script
├── generate_data.py                # Dataset generation script
└── README.md
```

---

## 📊 Dataset Features

| Feature | Description |
|---|---|
| Loan_ID | Unique loan identifier |
| Age | Borrower age |
| Annual_Income | Borrower annual income (₹) |
| Employment_Type | Salaried / Self-Employed / Business / Freelancer / Govt |
| State | Indian state (8 states) |
| Loan_Amount | Disbursed loan amount (₹) |
| Loan_Purpose | Home / Vehicle / Business / Education / Personal etc. |
| Interest_Rate | Rate of interest (%) |
| Tenure_Months | Loan tenure in months |
| Credit_Score | CIBIL score (550–850) |
| Loan_Grade | Risk grade (A–E) |
| DTI_Ratio | Debt-to-Income ratio (%) |
| Monthly_EMI | EMI amount (₹) |
| Outstanding_Balance | Remaining balance (₹) |
| Missed_Payments | Number of missed EMIs |
| Loan_Status | Good Standing / Defaulted |
| Default | 0 = Good, 1 = Default |
| Issue_Date | Loan disbursement date |

---

## 🔍 Key Findings

### Default Rate Analysis
- **Overall Default Rate:** 32.5%
- **Grade E loans** have the highest default rate (55%+)
- **Freelancers** show highest default risk among employment types
- **Credit Score < 620** borrowers default at 3x the rate of 750+ borrowers

### Financial Risk Insights
- **DTI > 40%** combined with **Credit Score < 650** = highest risk segment
- **Home Purchase loans** have the lowest default rate
- **Personal loans** carry significantly higher default risk
- Top 3 states by default rate identified for targeted monitoring

### ML Model Performance
- **Algorithm:** Random Forest Classifier
- **AUC Score:** 0.992
- **Accuracy:** 98%
- **Top Predictors:** Missed Payments, Credit Score, DTI Ratio, Loan Grade

---

## 🛠️ Tools & Technologies

| Tool | Usage |
|---|---|
| **Python** | Data cleaning, EDA, visualization, ML modeling |
| **Pandas & NumPy** | Data manipulation and statistical analysis |
| **Matplotlib & Seaborn** | Charts and dashboards |
| **Scikit-learn** | Random Forest, model evaluation |
| **SQL** | Business queries, aggregations, filtering |
| **Microsoft Excel** | Multi-sheet reporting, pivot analysis |
| **Power BI** | Interactive dashboard (see dashboard_exports/) |

---

## 📈 SQL Analysis Highlights

10 business queries covering:
- Portfolio overview & KPIs
- Default rate by loan grade, credit score band, employment type
- State-wise performance
- High-risk loan identification
- Monthly disbursement trends
- Income bracket analysis

---

## 🚀 How to Run

```bash
# 1. Clone the repository
git clone https://github.com/yourusername/bank-loan-risk-analysis

# 2. Install dependencies
pip install pandas numpy matplotlib seaborn scikit-learn openpyxl xlsxwriter

# 3. Generate dataset
python generate_data.py

# 4. Run full analysis
python loan_analysis.py
```

---

## 💼 Skills Demonstrated

- ✅ Financial data validation & quality checks
- ✅ Data cleaning & reconciliation
- ✅ SQL querying & aggregation
- ✅ Risk segmentation & pattern analysis
- ✅ Dashboard & MIS report creation
- ✅ Machine learning for financial risk prediction
- ✅ Excel multi-sheet reporting
- ✅ Business insight communication

---

## 📧 Contact

**K V S R S Gopi Chand**  
📧 21gopi.04@gmail.com  
📞 +91 8978137485  
🔗 [LinkedIn](https://www.linkedin.com/in/gopi-chand-04a988248)

---

*This project demonstrates practical financial data analysis skills applicable to roles in banking operations, risk analytics, audit support, and compliance at organizations like Wells Fargo, BlackRock, Big 4 firms, and other financial institutions.*
