import pandas as pd
import numpy as np
import random
from datetime import datetime, timedelta

np.random.seed(42)
random.seed(42)
n = 5000

# Loan purposes
purposes = ['Home Purchase', 'Vehicle Loan', 'Business Expansion', 'Education', 'Personal', 'Debt Consolidation', 'Medical']
purpose_weights = [0.25, 0.18, 0.15, 0.12, 0.13, 0.10, 0.07]

# Employment types
emp_types = ['Salaried', 'Self-Employed', 'Business Owner', 'Freelancer', 'Government Employee']
emp_weights = [0.45, 0.20, 0.15, 0.10, 0.10]

# Loan grades
grades = ['A', 'B', 'C', 'D', 'E']
grade_weights = [0.20, 0.30, 0.25, 0.15, 0.10]

states = ['Telangana', 'Maharashtra', 'Karnataka', 'Tamil Nadu', 'Delhi', 'Gujarat', 'Rajasthan', 'West Bengal']

start_date = datetime(2020, 1, 1)

loan_ids = [f'LN{str(i).zfill(6)}' for i in range(1, n+1)]
ages = np.random.randint(22, 65, n)
annual_incomes = np.random.choice(
    [np.random.randint(300000, 600000),
     np.random.randint(600000, 1200000),
     np.random.randint(1200000, 3000000)],
    n
)
annual_incomes = np.random.randint(300000, 3000000, n)
loan_amounts = np.random.randint(100000, 5000000, n)
interest_rates = np.round(np.random.uniform(7.5, 18.5, n), 2)
tenures = np.random.choice([12, 24, 36, 48, 60, 84, 120], n)
credit_scores = np.random.randint(550, 850, n)
grade_list = np.random.choice(grades, n, p=grade_weights)
purpose_list = np.random.choice(purposes, n, p=purpose_weights)
emp_list = np.random.choice(emp_types, n, p=emp_weights)
state_list = np.random.choice(states, n)
issue_dates = [start_date + timedelta(days=random.randint(0, 1600)) for _ in range(n)]

# DTI ratio
dti = np.round((loan_amounts / annual_incomes) * 100, 2)

# Default logic based on credit score, dti, grade
default_prob = []
for i in range(n):
    prob = 0.05
    if credit_scores[i] < 620: prob += 0.25
    elif credit_scores[i] < 680: prob += 0.12
    if dti[i] > 50: prob += 0.15
    elif dti[i] > 35: prob += 0.08
    if grade_list[i] == 'E': prob += 0.20
    elif grade_list[i] == 'D': prob += 0.12
    elif grade_list[i] == 'C': prob += 0.05
    if emp_list[i] == 'Freelancer': prob += 0.08
    default_prob.append(min(prob, 0.85))

default_status = [1 if random.random() < p else 0 for p in default_prob]
loan_status = ['Defaulted' if d == 1 else 'Good Standing' for d in default_status]

# EMI calculation
monthly_rate = interest_rates / (12 * 100)
emi = np.round((loan_amounts * monthly_rate * (1 + monthly_rate)**tenures) / ((1 + monthly_rate)**tenures - 1), 2)

# Outstanding balance
outstanding = np.round(loan_amounts * np.random.uniform(0.1, 0.95, n), 2)

# Missed payments
missed_payments = [np.random.randint(3, 12) if d == 1 else np.random.randint(0, 2) for d in default_status]

df = pd.DataFrame({
    'Loan_ID': loan_ids,
    'Age': ages,
    'Annual_Income': annual_incomes,
    'Employment_Type': emp_list,
    'State': state_list,
    'Loan_Amount': loan_amounts,
    'Loan_Purpose': purpose_list,
    'Interest_Rate': interest_rates,
    'Tenure_Months': tenures,
    'Credit_Score': credit_scores,
    'Loan_Grade': grade_list,
    'DTI_Ratio': dti,
    'Monthly_EMI': emi,
    'Outstanding_Balance': outstanding,
    'Missed_Payments': missed_payments,
    'Loan_Status': loan_status,
    'Default': default_status,
    'Issue_Date': [d.strftime('%Y-%m-%d') for d in issue_dates]
})

df.to_csv('/home/claude/bank_loan_project/data/bank_loan_data.csv', index=False)
print(f"Dataset created: {len(df)} records")
print(f"Default rate: {df['Default'].mean():.2%}")
print(df.head(3))
