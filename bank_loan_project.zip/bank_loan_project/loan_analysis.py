#!/usr/bin/env python3
"""
Bank Loan Risk Analysis — Complete Python Analysis
Author: K V S R S Gopi Chand
Tools: Python (Pandas, NumPy, Matplotlib, Seaborn, Scikit-learn)
Dataset: 5,000 Indian Bank Loan Records
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score
from sklearn.preprocessing import LabelEncoder
import warnings
warnings.filterwarnings('ignore')

# ── Style ─────────────────────────────────────────────────────
plt.rcParams['figure.facecolor'] = '#F8F9FA'
plt.rcParams['axes.facecolor'] = '#FFFFFF'
plt.rcParams['font.family'] = 'DejaVu Sans'
NAVY = '#1B3A6B'
RED = '#C0392B'
GREEN = '#1E8449'
GOLD = '#D4AC0D'
COLORS = [NAVY, '#2E86C1', '#1E8449', '#C0392B', '#8E44AD', '#E67E22', '#17A589']

# ── Load Data ─────────────────────────────────────────────────
df = pd.read_csv('/home/claude/bank_loan_project/data/bank_loan_data.csv')
print(f"✅ Dataset loaded: {df.shape[0]} rows × {df.shape[1]} columns")
print(f"   Default Rate: {df['Default'].mean():.2%}")
print(f"   Total Loan Amount: ₹{df['Loan_Amount'].sum()/1e7:.1f} Crore")

# ═══════════════════════════════════════════════════════════════
# FIGURE 1 — EXECUTIVE DASHBOARD (KPI Cards + Key Charts)
# ═══════════════════════════════════════════════════════════════
fig = plt.figure(figsize=(20, 14))
fig.patch.set_facecolor('#EEF2F8')
plt.suptitle('Bank Loan Risk Analysis Dashboard', 
             fontsize=22, fontweight='bold', color=NAVY, y=0.98)
plt.figtext(0.5, 0.955, 'K V S R S Gopi Chand  |  Python + SQL + Power BI  |  5,000 Loan Records (2020–2024)',
            ha='center', fontsize=10, color='#555555')

gs = fig.add_gridspec(3, 4, hspace=0.45, wspace=0.35,
                      left=0.05, right=0.97, top=0.92, bottom=0.05)

# ── KPI Cards ─────────────────────────────────────────────────
kpis = [
    ("Total Loans", f"{len(df):,}", NAVY),
    ("Total Disbursed", f"₹{df['Loan_Amount'].sum()/1e7:.1f}Cr", '#2E86C1'),
    ("Default Rate", f"{df['Default'].mean():.1%}", RED),
    ("Avg Credit Score", f"{df['Credit_Score'].mean():.0f}", GREEN),
]
for i, (label, value, color) in enumerate(kpis):
    ax = fig.add_subplot(gs[0, i])
    ax.set_facecolor(color)
    ax.text(0.5, 0.62, value, transform=ax.transAxes,
            ha='center', va='center', fontsize=22, fontweight='bold', color='white')
    ax.text(0.5, 0.22, label, transform=ax.transAxes,
            ha='center', va='center', fontsize=11, color='white', alpha=0.9)
    ax.set_xticks([]); ax.set_yticks([])
    for spine in ax.spines.values(): spine.set_visible(False)

# ── Chart 1: Default Rate by Loan Grade ───────────────────────
ax1 = fig.add_subplot(gs[1, 0:2])
grade_df = df.groupby('Loan_Grade')['Default'].agg(['sum','count'])
grade_df['rate'] = grade_df['sum'] / grade_df['count'] * 100
bars = ax1.bar(grade_df.index, grade_df['rate'], 
               color=[GREEN, '#A9DFBF', GOLD, '#E59866', RED])
ax1.set_title('Default Rate by Loan Grade', fontweight='bold', color=NAVY, fontsize=12)
ax1.set_xlabel('Loan Grade'); ax1.set_ylabel('Default Rate (%)')
ax1.set_ylim(0, grade_df['rate'].max() * 1.2)
for bar, val in zip(bars, grade_df['rate']):
    ax1.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.5,
             f'{val:.1f}%', ha='center', va='bottom', fontweight='bold', fontsize=10)

# ── Chart 2: Default Rate by Credit Score Band ────────────────
ax2 = fig.add_subplot(gs[1, 2:4])
bins = [550, 580, 620, 670, 740, 800, 850]
labels = ['550-580\n(Poor)', '580-620\n(Fair-)', '620-670\n(Fair+)', 
          '670-740\n(Good)', '740-800\n(V.Good)', '800+\n(Excellent)']
df['CS_Band'] = pd.cut(df['Credit_Score'], bins=bins, labels=labels)
cs_df = df.groupby('CS_Band', observed=True)['Default'].mean() * 100
ax2.plot(range(len(cs_df)), cs_df.values, 'o-', color=RED, linewidth=2.5, markersize=8)
ax2.fill_between(range(len(cs_df)), cs_df.values, alpha=0.15, color=RED)
ax2.set_xticks(range(len(cs_df))); ax2.set_xticklabels(labels, fontsize=8)
ax2.set_title('Default Rate by Credit Score Band', fontweight='bold', color=NAVY, fontsize=12)
ax2.set_ylabel('Default Rate (%)')
for i, v in enumerate(cs_df.values):
    ax2.annotate(f'{v:.1f}%', (i, v), textcoords="offset points", 
                 xytext=(0, 8), ha='center', fontsize=9, fontweight='bold')

# ── Chart 3: Loan Purpose Distribution ────────────────────────
ax3 = fig.add_subplot(gs[2, 0:2])
purpose_df = df.groupby('Loan_Purpose').agg(
    Total=('Loan_Amount', 'sum'),
    Default_Rate=('Default', 'mean')
).sort_values('Total', ascending=True)
bars3 = ax3.barh(purpose_df.index, purpose_df['Total']/1e6, color=COLORS[:len(purpose_df)])
ax3.set_title('Total Loan Amount by Purpose (₹ Million)', fontweight='bold', color=NAVY, fontsize=12)
ax3.set_xlabel('Total Amount (₹ Million)')
for bar, dr in zip(bars3, purpose_df['Default_Rate']):
    ax3.text(bar.get_width() + 1, bar.get_y() + bar.get_height()/2,
             f'{dr:.0%}', va='center', fontsize=8, color=RED, fontweight='bold')
ax3.text(purpose_df['Total'].max()/1e6 * 0.75, -0.7, '← Default Rate', 
         color=RED, fontsize=8)

# ── Chart 4: Employment Type Risk ─────────────────────────────
ax4 = fig.add_subplot(gs[2, 2:4])
emp_df = df.groupby('Employment_Type')['Default'].mean() * 100
emp_df = emp_df.sort_values(ascending=False)
colors4 = [RED if v > 35 else GOLD if v > 25 else GREEN for v in emp_df.values]
bars4 = ax4.bar(range(len(emp_df)), emp_df.values, color=colors4)
ax4.set_xticks(range(len(emp_df)))
ax4.set_xticklabels([e.replace(' ', '\n') for e in emp_df.index], fontsize=8)
ax4.set_title('Default Rate by Employment Type', fontweight='bold', color=NAVY, fontsize=12)
ax4.set_ylabel('Default Rate (%)')
for bar, val in zip(bars4, emp_df.values):
    ax4.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.3,
             f'{val:.1f}%', ha='center', fontsize=9, fontweight='bold')

plt.savefig('/home/claude/bank_loan_project/outputs/01_executive_dashboard.png', 
            dpi=150, bbox_inches='tight')
plt.close()
print("✅ Chart 1: Executive Dashboard saved")

# ═══════════════════════════════════════════════════════════════
# FIGURE 2 — RISK & FINANCIAL ANALYSIS
# ═══════════════════════════════════════════════════════════════
fig2, axes = plt.subplots(2, 3, figsize=(20, 12))
fig2.patch.set_facecolor('#EEF2F8')
fig2.suptitle('Risk & Financial Deep-Dive Analysis', 
              fontsize=18, fontweight='bold', color=NAVY, y=1.01)

# DTI vs Default
ax = axes[0,0]
default_dti = df[df['Default']==1]['DTI_Ratio']
good_dti = df[df['Default']==0]['DTI_Ratio']
ax.hist(good_dti, bins=40, alpha=0.6, color=GREEN, label='Good Standing', density=True)
ax.hist(default_dti, bins=40, alpha=0.6, color=RED, label='Defaulted', density=True)
ax.set_title('DTI Ratio Distribution by Loan Status', fontweight='bold', color=NAVY)
ax.set_xlabel('DTI Ratio (%)'); ax.set_ylabel('Density')
ax.legend(); ax.axvline(40, color='black', linestyle='--', alpha=0.5, label='Risk Threshold 40%')

# Credit Score vs Loan Amount Scatter
ax = axes[0,1]
sample = df.sample(500, random_state=42)
colors_scatter = [RED if d==1 else GREEN for d in sample['Default']]
ax.scatter(sample['Credit_Score'], sample['Loan_Amount']/1e5, 
           c=colors_scatter, alpha=0.5, s=20)
ax.set_title('Credit Score vs Loan Amount', fontweight='bold', color=NAVY)
ax.set_xlabel('Credit Score'); ax.set_ylabel('Loan Amount (₹ Lakh)')
red_patch = mpatches.Patch(color=RED, label='Defaulted')
green_patch = mpatches.Patch(color=GREEN, label='Good Standing')
ax.legend(handles=[red_patch, green_patch])

# State-wise default rate
ax = axes[0,2]
state_df = df.groupby('State')['Default'].mean() * 100
state_df = state_df.sort_values(ascending=False)
colors_state = [RED if v > 35 else GOLD if v > 30 else GREEN for v in state_df.values]
ax.barh(state_df.index, state_df.values, color=colors_state)
ax.set_title('Default Rate by State', fontweight='bold', color=NAVY)
ax.set_xlabel('Default Rate (%)')
for i, v in enumerate(state_df.values):
    ax.text(v + 0.2, i, f'{v:.1f}%', va='center', fontsize=9)

# Monthly trend
ax = axes[1,0]
df['Issue_Date'] = pd.to_datetime(df['Issue_Date'])
df['Month'] = df['Issue_Date'].dt.to_period('Q')
monthly = df.groupby('Month').agg(
    Loans=('Loan_ID','count'),
    Default_Rate=('Default','mean')
).reset_index()
monthly['Month_str'] = monthly['Month'].astype(str)
ax2_twin = ax.twinx()
ax.bar(range(len(monthly)), monthly['Loans'], color=NAVY, alpha=0.6, label='Loans Issued')
ax2_twin.plot(range(len(monthly)), monthly['Default_Rate']*100, 'o-', 
              color=RED, linewidth=2, label='Default Rate %')
ax.set_xticks(range(0, len(monthly), 2))
ax.set_xticklabels(monthly['Month_str'].iloc[::2], rotation=45, fontsize=7)
ax.set_title('Quarterly Loan Volume & Default Trend', fontweight='bold', color=NAVY)
ax.set_ylabel('Loans Issued', color=NAVY)
ax2_twin.set_ylabel('Default Rate (%)', color=RED)

# Income bracket
ax = axes[1,1]
income_bins = [0, 500000, 1000000, 2000000, float('inf')]
income_labels = ['<5L', '5L-10L', '10L-20L', '>20L']
df['Income_Band'] = pd.cut(df['Annual_Income'], bins=income_bins, labels=income_labels)
inc_df = df.groupby('Income_Band', observed=True)['Default'].mean() * 100
ax.bar(inc_df.index, inc_df.values, color=[RED, GOLD, '#A9DFBF', GREEN])
ax.set_title('Default Rate by Income Bracket', fontweight='bold', color=NAVY)
ax.set_xlabel('Annual Income'); ax.set_ylabel('Default Rate (%)')
for i, v in enumerate(inc_df.values):
    ax.text(i, v + 0.3, f'{v:.1f}%', ha='center', fontweight='bold')

# Outstanding balance by grade
ax = axes[1,2]
grade_bal = df.groupby('Loan_Grade')['Outstanding_Balance'].sum() / 1e6
ax.bar(grade_bal.index, grade_bal.values, 
       color=[GREEN, '#A9DFBF', GOLD, '#E59866', RED])
ax.set_title('Total Outstanding Balance by Grade (₹M)', fontweight='bold', color=NAVY)
ax.set_xlabel('Loan Grade'); ax.set_ylabel('Outstanding Balance (₹ Million)')
for i, v in enumerate(grade_bal.values):
    ax.text(i, v + 0.5, f'₹{v:.0f}M', ha='center', fontsize=9, fontweight='bold')

plt.tight_layout()
plt.savefig('/home/claude/bank_loan_project/outputs/02_risk_analysis.png',
            dpi=150, bbox_inches='tight')
plt.close()
print("✅ Chart 2: Risk Analysis saved")

# ═══════════════════════════════════════════════════════════════
# FIGURE 3 — ML DEFAULT PREDICTION MODEL
# ═══════════════════════════════════════════════════════════════
# Encode categoricals
df_ml = df.copy()
le = LabelEncoder()
for col in ['Employment_Type', 'State', 'Loan_Purpose', 'Loan_Grade']:
    df_ml[col] = le.fit_transform(df_ml[col])

features = ['Age', 'Annual_Income', 'Loan_Amount', 'Interest_Rate', 
            'Tenure_Months', 'Credit_Score', 'DTI_Ratio', 'Monthly_EMI',
            'Employment_Type', 'Loan_Grade', 'Loan_Purpose', 'Missed_Payments']

X = df_ml[features]
y = df_ml['Default']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
y_prob = model.predict_proba(X_test)[:, 1]
auc = roc_auc_score(y_test, y_prob)

print(f"\n✅ ML Model trained | AUC Score: {auc:.3f}")
print(classification_report(y_test, y_pred))

fig3, axes = plt.subplots(1, 3, figsize=(18, 6))
fig3.patch.set_facecolor('#EEF2F8')
fig3.suptitle(f'Default Prediction Model — Random Forest Classifier (AUC: {auc:.3f})',
              fontsize=16, fontweight='bold', color=NAVY)

# Feature Importance
ax = axes[0]
feat_imp = pd.Series(model.feature_importances_, index=features).sort_values(ascending=True)
colors_fi = [RED if f in ['Missed_Payments', 'Credit_Score', 'DTI_Ratio'] else NAVY for f in feat_imp.index]
feat_imp.plot(kind='barh', ax=ax, color=colors_fi)
ax.set_title('Feature Importance', fontweight='bold', color=NAVY)
ax.set_xlabel('Importance Score')

# Confusion Matrix
ax = axes[1]
cm = confusion_matrix(y_test, y_pred)
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=ax,
            xticklabels=['Good', 'Default'], yticklabels=['Good', 'Default'])
ax.set_title('Confusion Matrix', fontweight='bold', color=NAVY)
ax.set_ylabel('Actual'); ax.set_xlabel('Predicted')

# Risk Score Distribution
ax = axes[2]
ax.hist(y_prob[y_test==0], bins=30, alpha=0.6, color=GREEN, label='Good Standing', density=True)
ax.hist(y_prob[y_test==1], bins=30, alpha=0.6, color=RED, label='Defaulted', density=True)
ax.axvline(0.5, color='black', linestyle='--', label='Decision Threshold')
ax.set_title('Predicted Risk Score Distribution', fontweight='bold', color=NAVY)
ax.set_xlabel('Predicted Default Probability')
ax.set_ylabel('Density')
ax.legend()

plt.tight_layout()
plt.savefig('/home/claude/bank_loan_project/outputs/03_ml_model.png',
            dpi=150, bbox_inches='tight')
plt.close()
print("✅ Chart 3: ML Model saved")

# ═══════════════════════════════════════════════════════════════
# EXCEL REPORT
# ═══════════════════════════════════════════════════════════════
with pd.ExcelWriter('/home/claude/bank_loan_project/outputs/Loan_Analysis_Report.xlsx',
                    engine='xlsxwriter') as writer:
    
    # Sheet 1: Raw Data Sample
    df.head(500).to_excel(writer, sheet_name='Loan_Data', index=False)
    
    # Sheet 2: Summary KPIs
    summary = pd.DataFrame({
        'Metric': ['Total Loans', 'Total Disbursed (₹)', 'Total Outstanding (₹)',
                   'Default Rate', 'Avg Credit Score', 'Avg Interest Rate',
                   'Avg Loan Amount (₹)', 'Avg DTI Ratio'],
        'Value': [len(df), f"₹{df['Loan_Amount'].sum():,.0f}", 
                  f"₹{df['Outstanding_Balance'].sum():,.0f}",
                  f"{df['Default'].mean():.2%}", f"{df['Credit_Score'].mean():.0f}",
                  f"{df['Interest_Rate'].mean():.2f}%",
                  f"₹{df['Loan_Amount'].mean():,.0f}", f"{df['DTI_Ratio'].mean():.2f}%"]
    })
    summary.to_excel(writer, sheet_name='KPI_Summary', index=False)
    
    # Sheet 3: Grade Analysis
    grade_analysis = df.groupby('Loan_Grade').agg(
        Total_Loans=('Loan_ID','count'),
        Total_Amount=('Loan_Amount','sum'),
        Avg_Interest_Rate=('Interest_Rate','mean'),
        Avg_Credit_Score=('Credit_Score','mean'),
        Defaults=('Default','sum'),
        Default_Rate=('Default','mean')
    ).round(2)
    grade_analysis.to_excel(writer, sheet_name='Grade_Analysis')
    
    # Sheet 4: State Analysis
    state_analysis = df.groupby('State').agg(
        Total_Loans=('Loan_ID','count'),
        Total_Amount=('Loan_Amount','sum'),
        Defaults=('Default','sum'),
        Default_Rate=('Default','mean'),
        Avg_Credit_Score=('Credit_Score','mean')
    ).round(2).sort_values('Default_Rate', ascending=False)
    state_analysis.to_excel(writer, sheet_name='State_Analysis')
    
    # Sheet 5: High Risk Loans
    high_risk = df[(df['DTI_Ratio'] > 40) & (df['Credit_Score'] < 650)].sort_values('DTI_Ratio', ascending=False)
    high_risk.to_excel(writer, sheet_name='High_Risk_Loans', index=False)

print("✅ Excel Report saved")
print("\n🎯 All outputs generated successfully!")
print("   outputs/01_executive_dashboard.png")
print("   outputs/02_risk_analysis.png")
print("   outputs/03_ml_model.png")
print("   outputs/Loan_Analysis_Report.xlsx")
