-- ============================================================
-- Bank Loan Risk Analysis — SQL Queries
-- Author: K V S R S Gopi Chand
-- Dataset: 5,000 Loan Records | 2020–2024
-- ============================================================

-- ── 1. OVERVIEW: Total Loans, Amount, Default Rate ──────────
SELECT 
    COUNT(*) AS Total_Loans,
    SUM(Loan_Amount) AS Total_Loan_Amount,
    ROUND(AVG(Interest_Rate), 2) AS Avg_Interest_Rate,
    SUM(CASE WHEN Default = 1 THEN 1 ELSE 0 END) AS Total_Defaults,
    ROUND(100.0 * SUM(Default) / COUNT(*), 2) AS Default_Rate_Pct,
    SUM(Outstanding_Balance) AS Total_Outstanding
FROM bank_loan_data;

-- ── 2. DEFAULT RATE BY LOAN GRADE ───────────────────────────
SELECT 
    Loan_Grade,
    COUNT(*) AS Total_Loans,
    SUM(Default) AS Defaults,
    ROUND(100.0 * SUM(Default) / COUNT(*), 2) AS Default_Rate_Pct,
    ROUND(AVG(Interest_Rate), 2) AS Avg_Interest_Rate,
    ROUND(AVG(Credit_Score), 0) AS Avg_Credit_Score
FROM bank_loan_data
GROUP BY Loan_Grade
ORDER BY Loan_Grade;

-- ── 3. DEFAULT RATE BY CREDIT SCORE BAND ────────────────────
SELECT 
    CASE 
        WHEN Credit_Score >= 800 THEN '800+ (Excellent)'
        WHEN Credit_Score >= 740 THEN '740-799 (Very Good)'
        WHEN Credit_Score >= 670 THEN '670-739 (Good)'
        WHEN Credit_Score >= 580 THEN '580-669 (Fair)'
        ELSE 'Below 580 (Poor)'
    END AS Credit_Score_Band,
    COUNT(*) AS Total_Loans,
    SUM(Default) AS Defaults,
    ROUND(100.0 * SUM(Default) / COUNT(*), 2) AS Default_Rate_Pct,
    ROUND(AVG(Loan_Amount), 0) AS Avg_Loan_Amount
FROM bank_loan_data
GROUP BY Credit_Score_Band
ORDER BY MIN(Credit_Score) DESC;

-- ── 4. DEFAULT RATE BY EMPLOYMENT TYPE ──────────────────────
SELECT 
    Employment_Type,
    COUNT(*) AS Total_Loans,
    SUM(Default) AS Defaults,
    ROUND(100.0 * SUM(Default) / COUNT(*), 2) AS Default_Rate_Pct,
    ROUND(AVG(Annual_Income), 0) AS Avg_Annual_Income,
    ROUND(AVG(DTI_Ratio), 2) AS Avg_DTI_Ratio
FROM bank_loan_data
GROUP BY Employment_Type
ORDER BY Default_Rate_Pct DESC;

-- ── 5. LOAN PURPOSE ANALYSIS ────────────────────────────────
SELECT 
    Loan_Purpose,
    COUNT(*) AS Total_Loans,
    ROUND(AVG(Loan_Amount), 0) AS Avg_Loan_Amount,
    SUM(Loan_Amount) AS Total_Disbursed,
    SUM(Default) AS Defaults,
    ROUND(100.0 * SUM(Default) / COUNT(*), 2) AS Default_Rate_Pct
FROM bank_loan_data
GROUP BY Loan_Purpose
ORDER BY Total_Disbursed DESC;

-- ── 6. HIGH RISK LOANS (DTI > 40 AND Credit Score < 650) ────
SELECT 
    Loan_ID,
    Age,
    Annual_Income,
    Loan_Amount,
    DTI_Ratio,
    Credit_Score,
    Loan_Grade,
    Interest_Rate,
    Loan_Status
FROM bank_loan_data
WHERE DTI_Ratio > 40 AND Credit_Score < 650
ORDER BY DTI_Ratio DESC
LIMIT 20;

-- ── 7. STATE-WISE LOAN PERFORMANCE ──────────────────────────
SELECT 
    State,
    COUNT(*) AS Total_Loans,
    ROUND(SUM(Loan_Amount)/1000000, 2) AS Total_Amount_Millions,
    SUM(Default) AS Defaults,
    ROUND(100.0 * SUM(Default) / COUNT(*), 2) AS Default_Rate_Pct,
    ROUND(AVG(Credit_Score), 0) AS Avg_Credit_Score
FROM bank_loan_data
GROUP BY State
ORDER BY Default_Rate_Pct DESC;

-- ── 8. MONTHLY LOAN DISBURSEMENT TREND ──────────────────────
SELECT 
    SUBSTR(Issue_Date, 1, 7) AS Month,
    COUNT(*) AS Loans_Issued,
    ROUND(SUM(Loan_Amount)/1000000, 2) AS Amount_Millions,
    SUM(Default) AS Defaults,
    ROUND(100.0 * SUM(Default) / COUNT(*), 2) AS Default_Rate_Pct
FROM bank_loan_data
GROUP BY Month
ORDER BY Month;

-- ── 9. INCOME BRACKET ANALYSIS ──────────────────────────────
SELECT 
    CASE 
        WHEN Annual_Income < 500000 THEN 'Below 5L'
        WHEN Annual_Income < 1000000 THEN '5L - 10L'
        WHEN Annual_Income < 2000000 THEN '10L - 20L'
        ELSE 'Above 20L'
    END AS Income_Bracket,
    COUNT(*) AS Total_Loans,
    ROUND(AVG(Loan_Amount), 0) AS Avg_Loan_Amount,
    ROUND(AVG(DTI_Ratio), 2) AS Avg_DTI,
    ROUND(100.0 * SUM(Default) / COUNT(*), 2) AS Default_Rate_Pct
FROM bank_loan_data
GROUP BY Income_Bracket
ORDER BY MIN(Annual_Income);

-- ── 10. TOP 10 HIGHEST OUTSTANDING BALANCE DEFAULTERS ───────
SELECT 
    Loan_ID,
    Age,
    State,
    Loan_Amount,
    Outstanding_Balance,
    Missed_Payments,
    Credit_Score,
    Loan_Grade,
    Loan_Purpose
FROM bank_loan_data
WHERE Default = 1
ORDER BY Outstanding_Balance DESC
LIMIT 10;
